export default [
    {
      name:"Company Highlights",
      value:"companyHighlights"
    },
    {
      name:"Products",
      value:"products"
    },
    {
      name:"Customers",
      value:"customers"
    },
    {
      name:"Services",
      value:"services"
    },
    {
      name:"Production Facilities",
      value:"productionFacilities"
    },
    {
      name:"Certifications",
      value:"certifications"
    },
    {
      name:"Sustainability Compliance",
      value:"sustainabilityCompliance"
    }
  ]