function Footer(props){
    return (
        <footer className="hbox">
            <div>
                Serai Terms of Use and Privacy Policy.
            </div>
            <div>
                © 2020 SERAI LIMITED. All rights reserved.
            </div>
        </footer>
    )
}

export default Footer;